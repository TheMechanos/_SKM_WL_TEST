
#include "App.hpp"


int main(void) {
	App::getInstance()->run();
}


